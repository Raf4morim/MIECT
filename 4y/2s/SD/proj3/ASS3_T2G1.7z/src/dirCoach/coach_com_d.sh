source config
java clientSide.main.ClientTheRopeGameCoach $rmi_name $rmi_port $loggerFile