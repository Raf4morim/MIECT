source config
java clientSide.main.ClientTheRopeGameReferee $rmi_name $rmi_port $loggerFile