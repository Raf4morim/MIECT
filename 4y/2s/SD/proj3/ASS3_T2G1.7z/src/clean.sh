rm -rf */*.class */*/*.class
rm -rf *.zip