source config
java clientSide.main.ClientTheRopeGameContestant $rmi_name $rmi_port $loggerFile